using UnityEngine;
using UnityEngine.Timeline;

[CreateAssetMenu(fileName = "Forest_EndingSignal", menuName = "Signal/Forest_EndingSignal")]
public class Forest_EndingSignal : SignalAsset
{
    [SerializeField] private GameObject _owner;

    

}
