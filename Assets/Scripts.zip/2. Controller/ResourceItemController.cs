using UnityEngine;

public class ResourceItemController : ItemController
{
    public override void OnAction()
    {
        
    }
}
