using UnityEngine;

public class AimingState : AlivePlayerCombatState
{
    public AimingState(AlivePlayerStateMachine stateMachine) : base(stateMachine)
    {
    }
}
