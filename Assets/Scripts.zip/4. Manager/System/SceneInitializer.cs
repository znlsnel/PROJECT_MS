using FishNet.Object;
using UnityEngine;

public abstract class SceneInitializer : MonoBehaviour
{
    public abstract void Initialize();
}
