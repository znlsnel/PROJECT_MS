using UnityEngine;

public class ResourceGenerator : MonoBehaviour
{
    [SerializeField] private Transform _resourceRoot;
    [SerializeField] private Transform _itemRoot;

    private void Awake()
    {
           
    }
}
