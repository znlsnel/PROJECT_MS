using System;
using FishNet;
using FishNet.Object;
using FishNet.Connection;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using System.Linq;

public class QuickSlotHandler : NetworkBehaviour
{
    private static readonly string _selectSlotSound = "Sound/UI/Click_06.mp3";
    

    [SerializeField] private Transform itemRoot;
    [SerializeField] private Transform waeponRoot;

    private Storage quickSlotStorage;

    private ItemSlot selectedItemSlot;
    private ItemData selectedItemData;
    private GameObject selectedItemObject;

    public event Action<ItemSlot, GameObject> onSelectItem;


    public void Setup(Inventory inventory)
    {
        quickSlotStorage = inventory.QuickSlotStorage;

        InitInput();
        InitQuickSlot();
    }

    public override void OnStartClient()
    {
        SelectItem(0);
    }

    private void InitInput()
    {
        // 퀵 슬롯 키 할당
        for (int i = 0; i < Enum.GetValues(typeof(EQuickSlot)).Length; i++)
        {
            EQuickSlot quickSlot = (EQuickSlot)i;
            int idx = i;

            Managers.Input.GetInput(quickSlot).started += (InputAction.CallbackContext context) =>
            {
                Managers.Sound.Play(_selectSlotSound);
                SelectItem(idx);  
            };
        }
    }

    private void InitQuickSlot()
    {
        // 선택한 퀵슬롯이 변경되면 새로 업데이트
        for (int i = 0; i < quickSlotStorage.Count; i++)
        {
            int idx = i;
            quickSlotStorage.GetSlotByIdx(i).onChangeStack += (ItemSlot itemSlot) => 
            {
                if (selectedItemSlot == itemSlot && itemSlot.Data != selectedItemData)
                {
                    //Managers.Sound.Play(_selectSlotSound);
                    SelectItem(idx);
                }
            }; 
        }
    }

 
    private void SelectItem(int itemSlotIdx)
    {
        if (quickSlotStorage == null) 
            return;

        ItemSlot itemSlot = quickSlotStorage.GetSlotByIdx(itemSlotIdx);
        if (itemSlot == null || (itemSlot == selectedItemSlot && itemSlot.Data == selectedItemData)) 
            return;


        if (itemSlot.Data != selectedItemData) 
        {
            Broadcast_HideItem();

            if (itemSlot.Data != null)
            {
                EItemType itemType = itemSlot.Data.ItemType;
                Broadcast_ShowItem(itemSlotIdx, itemSlot.Data.PrefabPath, itemType);
                return;
            }
        } 
 
        onSelectItem?.Invoke(itemSlot, null); 
        selectedItemSlot = itemSlot;
        selectedItemData = itemSlot.Data;
    }



    [ServerRpc(RequireOwnership = false)]
    private void Broadcast_ShowItem(int slotIdx, string prefabPath, EItemType itemType)
    {
        ObserversRpcShowItem(slotIdx, prefabPath, itemType);
    }

    [ObserversRpc]
    private void ObserversRpcShowItem(int slotIdx, string prefabPath, EItemType itemType)
    {
        selectedItemObject = Managers.Pool.Get(prefabPath, transform); 
        selectedItemObject.transform.SetParent(itemType == EItemType.Weapon ? waeponRoot : itemRoot, false);
        selectedItemObject.transform.localPosition = Vector3.zero;  
        selectedItemObject.transform.localRotation = Quaternion.identity; 


        if (quickSlotStorage == null)
            return;
            
        ItemSlot itemSlot = quickSlotStorage.GetSlotByIdx(slotIdx);
        if (itemSlot != null)
        {
            onSelectItem?.Invoke(itemSlot, selectedItemObject);  
            selectedItemSlot = itemSlot; 
            selectedItemData = itemSlot.Data;
        } 
    }

    [ServerRpc(RequireOwnership = false)]
    private void Broadcast_HideItem()
    {
       ObserversRpcHideItem();
    }

    [ObserversRpc]
    private void ObserversRpcHideItem()
    {
        if (selectedItemObject != null){
            Managers.Pool.Release(selectedItemObject);
            selectedItemObject = null;
        }
    }
}
